import React from 'react'
import{
    BrowserRouter as Router,
    Route,
    Redirect,
    Switch,
    
}from 'react-router-dom';
const MesajeGuvern = () => {
    return(
        <div classNme="container">
            <h1 className="text-center" style={{paddingTop:"30%"}}>
               Mesaje Guvern
            </h1>
        </div>
    );
}

export default MesajeGuvern;