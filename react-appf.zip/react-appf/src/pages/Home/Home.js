import React from 'react'
import{
    BrowserRouter as Router,
    Route,
    Redirect,
    Switch,
    
}from 'react-router-dom';
const Home = () => {
    return(
        <div classNme="container">
            <h1 className="text-center" style={{paddingTop:"30%"}}>
               Home
            </h1>
        </div>
    );
}

export default Home;