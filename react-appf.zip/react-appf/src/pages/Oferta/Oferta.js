import React from 'react'

const Oferta = () => {
    return(
        <div classNme="container">
            <h1 className="text-center" style={{paddingTop:"30%"}}>
               Oferta
            </h1>
        </div>
    );
}

export default Oferta;