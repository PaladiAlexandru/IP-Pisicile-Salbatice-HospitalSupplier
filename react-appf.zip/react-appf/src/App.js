import React from 'react';
import{
    BrowserRouter as Router,
    Route,
    Redirect,
    Switch,
    
}from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './pages/Home/Home';
import Cerere from './pages/Cerere/Cerere';
import Oferta from './pages/Oferta/Oferta';
import MesajeGuvern from './pages/MesajeGuvern/MesajeGuvern';
import IstoricComenzi from './pages/IstoricComenzi/IstoricComenzi';
import IstoricAprovizionariGuvern from './pages/IstoricAprovizionariGuvern/Istoricapr';
import Navbar from './Components/Navbar/Navbar';
const App=() =>{
    return(
    <Router>
        <Navbar/>
        <main>
            <Route path="/" exact>
                <Home/>

            </Route>
            <Route path="/Oferta" exact>
                <Oferta/>
                
            </Route>
            <Route path="/Cerere" exact>
                <Cerere/>
                
            </Route>
            <Route path="/MesajeGuvern" exact>
                <MesajeGuvern/>
                
            </Route>
            <Route path="/IstoricComenzi" exact>
                <IstoricComenzi/>
                
            </Route>
            <Route path="/IstoricApr" exact>
                <IstoricAprovizionariGuvern/>
                
            </Route>
            <Redirect to="/"/>
        </main>
    </Router>
    );
}
export default App;